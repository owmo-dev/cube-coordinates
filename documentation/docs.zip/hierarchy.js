var hierarchy =
[
    [ "Container", "class_cube_coordinates_1_1_container.html", null ],
    [ "Coordinate", "class_cube_coordinates_1_1_coordinate.html", null ],
    [ "MonoBehaviour", null, [
      [ "Coordinates", "class_cube_coordinates_1_1_coordinates.html", null ],
      [ "MeshCreator", "class_cube_coordinates_1_1_mesh_creator.html", null ]
    ] ]
];