var class_cube_coordinates_1_1_coordinate =
[
    [ "Type", "class_cube_coordinates_1_1_coordinate.html#a1d1cfd8ffb84e947f82999c682b666a7", [
      [ "None", "class_cube_coordinates_1_1_coordinate.html#a1d1cfd8ffb84e947f82999c682b666a7a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Prefab", "class_cube_coordinates_1_1_coordinate.html#a1d1cfd8ffb84e947f82999c682b666a7afc149351d98dcbf17361c6a449e6355e", null ],
      [ "GenerateMesh", "class_cube_coordinates_1_1_coordinate.html#a1d1cfd8ffb84e947f82999c682b666a7a72add83c48b4587dca5962c279efee13", null ]
    ] ],
    [ "Coordinate", "class_cube_coordinates_1_1_coordinate.html#a9e861faf334c45db8f3389322e7f9127", null ],
    [ "SetGameObject", "class_cube_coordinates_1_1_coordinate.html#ac369fcb8d9c29bcd0e2f819dcdbb4f79", null ],
    [ "gCost", "class_cube_coordinates_1_1_coordinate.html#ac65382fd801b4bae1643a1dd3a99c233", null ],
    [ "hCost", "class_cube_coordinates_1_1_coordinate.html#ac8866266744bf1dab28834efb297cf9b", null ],
    [ "cube", "class_cube_coordinates_1_1_coordinate.html#a33012126162c3a6ef6eb3a598920442f", null ],
    [ "fCost", "class_cube_coordinates_1_1_coordinate.html#a19e83b48e709c1d63fee3ed6895a14c4", null ],
    [ "go", "class_cube_coordinates_1_1_coordinate.html#aab7cf8386fbb852f60300b76a71d7e6a", null ],
    [ "position", "class_cube_coordinates_1_1_coordinate.html#acfb76c74e507fea066625f69fbc8a146", null ]
];